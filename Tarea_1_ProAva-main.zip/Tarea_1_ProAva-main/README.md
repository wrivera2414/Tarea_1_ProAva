# Tarea_1_ProAva
Mi primera tarea en Java utilizando maven para calcular areas de figuras
