package hn.clinica.data.service;

import hn.clinica.data.entity.Citas;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface CitasRepository extends JpaRepository<Citas, Long>, JpaSpecificationExecutor<Citas> {

}
