import {applyTheme as _applyTheme} from './theme-clinicalpaii.generated.js';
export const applyTheme = _applyTheme;
