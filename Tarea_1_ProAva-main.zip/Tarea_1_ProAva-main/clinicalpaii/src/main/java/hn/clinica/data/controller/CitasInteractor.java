package hn.clinica.data.controller;

public interface CitasInteractor {
	
	void consultarCitas();
}
