package hn.clinica.data.controller;

public interface PacientesInteractor {
	
	void consultarPacientes();
}
